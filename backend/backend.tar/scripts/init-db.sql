-- PostgreSQL 初始化脚本（明睿教务系统）
-- 用途：创建业务账号、数据库及基础权限（幂等）
--
-- 执行方式（示例）：
--   sudo -u postgres psql -f backend/scripts/init-db.sql
--
-- 默认参数：
--   用户名：mingrui_user
--   数据库：mingrui_class
--   密码：StrongPassword_ChangeMe
-- 请在生产环境执行前务必替换默认密码。

DO $$
BEGIN
  IF NOT EXISTS (SELECT 1 FROM pg_roles WHERE rolname = 'mingrui_user') THEN
    CREATE ROLE mingrui_user LOGIN PASSWORD 'StrongPassword_ChangeMe';
  ELSE
    ALTER ROLE mingrui_user WITH LOGIN PASSWORD 'StrongPassword_ChangeMe';
  END IF;
END
$$;

DO $$
BEGIN
  IF NOT EXISTS (SELECT 1 FROM pg_database WHERE datname = 'mingrui_class') THEN
    CREATE DATABASE mingrui_class OWNER mingrui_user;
  END IF;
END
$$;

GRANT ALL PRIVILEGES ON DATABASE mingrui_class TO mingrui_user;

\connect mingrui_class;

GRANT USAGE, CREATE ON SCHEMA public TO mingrui_user;
ALTER SCHEMA public OWNER TO mingrui_user;
ALTER DATABASE mingrui_class OWNER TO mingrui_user;

ALTER DEFAULT PRIVILEGES IN SCHEMA public
GRANT ALL ON TABLES TO mingrui_user;

ALTER DEFAULT PRIVILEGES IN SCHEMA public
GRANT ALL ON SEQUENCES TO mingrui_user;
